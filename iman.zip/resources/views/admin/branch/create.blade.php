@extends('main.manager')

@section('content')

<!-- Page title -->
<div class="page-header d-print-none">
    <div class="row align-items-center">
        <div class="col">
            <h2 class="page-title">
                Create new branch

            </h2>
        </div>
    </div>


</div>
<div class="card">
    @include('main.error')
   <form action="{{ route('branch.store') }}" method="post" enctype="multipart/form-data">
    @csrf
    @method('post')
    <div class="card-body ">
        <div class="row row-cards">
            <div class="col-xl-12">

                  <div class="mb-3">
                    <label class="form-label">User Name</label>
                    <input type="text" name="username" class="form-control"  value="{{ old('username') }}"  placeholder="Enter User Name">
                  </div>

                  <div class="mb-3">
                    <label class="form-label">Company name  </label>
                    <input type="text" name="company" class="form-control"  value="{{ old('company') }}"  placeholder="Company name">
                  </div>
                  <div class="mb-3">
                    <label class="form-label">Contact person</label>
                    <input type="text" name="person" class="form-control"  value="{{ old('person') }}"  placeholder="Enter Contact person">
                  </div>
                  <div class="mb-3">
                    <label class="form-label">Phone</label>
                    <input type="tell" name="phone" class="form-control"  value="{{ old('phone') }}"  placeholder="Enter User Phone">
                  </div>

                  <div class="mb-3">
                    <label class="form-label">Tax number</label>
                    <input type="tell" name="tax" class="form-control"  value="{{ old('tax') }}"  placeholder="Enter Tax number">
                  </div>
                  <div class="mb-3">
                    <div class="form-label">Country</div>
                    <select class="form-select select2" name="country_id" id="country">
                        <option value="">please select</option>
                        @foreach (App\Models\Country::all() as $country)
                        <option {{ old('country_id')== $country->id?:'selected' }} value="{{ $country->id }}">{{ $country->en_name }}</option>
                        @endforeach
                    </select>
                  </div>

                  <div class="mb-3">
                    <label class="form-label">Address <span class="form-label-description"></span></label>
                    <textarea class="form-control" name="address" rows="6" placeholder="Address..">{{old('address') }}</textarea>
                  </div>
                  <div class="mb-3">
                    <div class="form-label">Company logo jpg:
                    </div>
                    <input type="file" accept="image/*" name="logo" class="form-control" >
                  </div>

                  <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="text" name="password" class="form-control"  value="{{ old('password') }}"  placeholder="Enter Password ">
                  </div>
            </div>
        </div>
    </div>
    <div class="card-footer text-end">
        <div class="d-flex">
          <a href="{{ route('branch.index') }}" class="btn btn-link">Cancel</a>
          <button type="submit" class="btn btn-primary ms-auto">Send data</button>
        </div>
      </div>
   </form>
</div>



@endsection
