<?php if($errors->any()): ?>
    <div class="er" id="er">
        <?php echo implode('', $errors->all('<span class="text text-danger">:message</span> </br>')); ?>

    </div>
<?php endif; ?>
<?php /**PATH G:\laravelProject\iman\resources\views/main/error.blade.php ENDPATH**/ ?>