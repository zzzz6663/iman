<?php $__env->startSection('content'); ?>

<!-- Page title -->
<div class="page-header d-print-none">
    <div class="row align-items-center">
        <div class="col">
            <h2 class="page-title">
                Create new staff

            </h2>
        </div>
    </div>


</div>
<div class="card">
    <?php echo $__env->make('main.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <form action="<?php echo e(route('staff.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('post'); ?>
    <div class="card-body ">
        <div class="row row-cards">
            <div class="col-xl-12">

                  <div class="mb-3">
                    <label class="form-label"> Name</label>
                    <input type="text" name="name" class="form-control"  value="<?php echo e(old('name')); ?>"  placeholder="Enter  Name">
                  </div>

                  <div class="mb-3">
                    <label class="form-label">Last Name</label>
                    <input type="text" name="lastname" class="form-control"  value="<?php echo e(old('lastname')); ?>"  placeholder="Enter  Last Name">
                  </div>

                  <div class="mb-3">
                    <label class="form-label">User Name</label>
                    <input type="text" name="username" class="form-control"  value="<?php echo e(old('username')); ?>"  placeholder="Enter User Name">
                  </div>




                  <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="text" name="password" class="form-control"  value="<?php echo e(old('password')); ?>"  placeholder="Enter Password ">
                  </div>
            </div>
        </div>
    </div>
    <div class="card-footer text-end">
        <div class="d-flex">
          <a href="<?php echo e(route('staff.index')); ?>" class="btn btn-link">Cancel</a>
          <button type="submit" class="btn btn-primary ms-auto">Send data</button>
        </div>
      </div>
   </form>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.manager', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\iman\resources\views/admin/order/create.blade.php ENDPATH**/ ?>