<?php $__env->startSection('content'); ?>
<div class="page-body">
    <div class="container-xl">
        <!-- Page title -->
        <div class="page-header d-print-none">
            <div class="row align-items-center">
                <div class="col">
                    <h2 class="page-title">
                        Agents
                        (<?php echo e($agents->total()); ?>)
                    </h2>
                </div>
            </div>
            <form class="bl" action="<?php echo e(route('client.index')); ?>" method="get">
                <?php echo csrf_field(); ?>
                <?php echo method_field('get'); ?>
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <div class="form-label">شهرستان</div>
                        <select value="<?php echo e(old('shahr_id')); ?>" class="form-select" name="shahr_id">
                        </select>
                    </div>
                    <div class="col-auto ms-auto d-print-none mt-4">
                        <div class="d-flex">
                            <input type="search" name="search" value="<?php echo e(request('search')); ?>" class="form-control d-inline-block w-9 me-3" placeholder="جستجوی نماینده  ">
                            <button class="btn btn-primary">
                                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-search" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                    <circle cx="10" cy="10" r="7"></circle>
                                    <line x1="21" y1="21" x2="15" y2="15"></line>
                                </svg>
                                جستوجو
                            </button>
                            <input type="submit"  class="form-control d-inline-block w-9 me-3" id="submit" name="excel" value="  excel  ">

                        </div>
                    </div>
                </div>
            </form>

        </div>
    </div>
</div>
<div class="page-body">
    <div class="container-xl">
        <div class="row row-cards">
            <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-lg-3">
                <div class="card">
                    <div class="card-body p-4 text-center">
                        <span class="avatar avatar-xl mb-3 avatar-rounded" style="background-image: url(<?php echo e($agent->avatar()); ?>)"></span>
                        <h2 class="m-0 mb-1"><a href="#">
                                <?php echo e($agent->name??' ---------- '); ?>

                                <?php echo e($agent->family??'---------- '); ?>

                            </a></h2>
                        <div class="text-muted">
                            <i class="ti ti-map-pin"></i>
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-map-pin" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="#2398b3" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                <circle cx="12" cy="11" r="3"></circle>
                                <path d="M17.657 16.657l-4.243 4.243a2 2 0 0 1 -2.827 0l-4.244 -4.243a8 8 0 1 1 11.314 0z"></path>
                            </svg>
                            <?php echo e($agent->ostan?$agent->ostan->name:'------ '); ?>

                            <?php echo e($agent->shahr?$agent->shahr->name:' ------'); ?>

                        </div>
                        <div class="mt-3">
                            <span class="badge avatar text-white bg-<?php echo e($agent->info_complete=='1' ?'green':'red'); ?>"><?php echo e($agent->info_complete=='1' ?'فعال':'غیر فعال'); ?></span>
                        </div>
                    </div>
                    <div class="d-flex">
                        <span class="card-btn">
                            <?php echo e($agent->mobile); ?>

                        </span>
                    </div>
                    <div class="d-flex">


                        <a href="<?php echo e(route('admin.users.show', $agent->id)); ?>" class="btn card-btn btn-success">
                            اطلاعات بیشتر
                        </a>
                    </div>
                </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <div class="d-flex mt-4">
            <?php echo e($agents->appends(Request::all())->links('admin.section.pagination')); ?>

        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.manager', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\iman\resources\views/admin/agent/all.blade.php ENDPATH**/ ?>