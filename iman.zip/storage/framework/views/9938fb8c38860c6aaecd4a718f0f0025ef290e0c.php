<?php $__env->startSection('content'); ?>

<!-- Page title -->
<div class="page-header d-print-none">
    <div class="row align-items-center">
        <div class="col">
            <h2 class="page-title">
                Create new branch

            </h2>
        </div>
    </div>


</div>
<div class="card">
    <?php echo $__env->make('main.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <form action="<?php echo e(route('branch.store')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('post'); ?>
    <div class="card-body ">
        <div class="row row-cards">
            <div class="col-xl-12">

                  <div class="mb-3">
                    <label class="form-label">User Name</label>
                    <input type="text" name="username" class="form-control"  value="<?php echo e(old('username')); ?>"  placeholder="Enter User Name">
                  </div>

                  <div class="mb-3">
                    <label class="form-label">Company name  </label>
                    <input type="text" name="company" class="form-control"  value="<?php echo e(old('company')); ?>"  placeholder="Company name">
                  </div>
                  <div class="mb-3">
                    <label class="form-label">Contact person</label>
                    <input type="text" name="person" class="form-control"  value="<?php echo e(old('person')); ?>"  placeholder="Enter Contact person">
                  </div>
                  <div class="mb-3">
                    <label class="form-label">Phone</label>
                    <input type="tell" name="phone" class="form-control"  value="<?php echo e(old('phone')); ?>"  placeholder="Enter User Phone">
                  </div>

                  <div class="mb-3">
                    <label class="form-label">Tax number</label>
                    <input type="tell" name="tax" class="form-control"  value="<?php echo e(old('tax')); ?>"  placeholder="Enter Tax number">
                  </div>
                  <div class="mb-3">
                    <div class="form-label">Country</div>
                    <select class="form-select select2" name="country_id" id="country">
                        <option value="">please select</option>
                        <?php $__currentLoopData = App\Models\Country::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e(old('country_id')== $country->id?:'selected'); ?> value="<?php echo e($country->id); ?>"><?php echo e($country->en_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>

                  <div class="mb-3">
                    <label class="form-label">Address <span class="form-label-description"></span></label>
                    <textarea class="form-control" name="address" rows="6" placeholder="Address.."><?php echo e(old('address')); ?></textarea>
                  </div>
                  <div class="mb-3">
                    <div class="form-label">Company logo jpg:
                    </div>
                    <input type="file" accept="image/*" name="logo" class="form-control" >
                  </div>

                  <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="text" name="password" class="form-control"  value="<?php echo e(old('password')); ?>"  placeholder="Enter Password ">
                  </div>
            </div>
        </div>
    </div>
    <div class="card-footer text-end">
        <div class="d-flex">
          <a href="<?php echo e(route('branch.index')); ?>" class="btn btn-link">Cancel</a>
          <button type="submit" class="btn btn-primary ms-auto">Send data</button>
        </div>
      </div>
   </form>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.manager', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\iman\resources\views/admin/branch/create.blade.php ENDPATH**/ ?>