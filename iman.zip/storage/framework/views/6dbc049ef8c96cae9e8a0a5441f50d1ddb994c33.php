<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <title>
        <?php if(auth()->guard()->check()): ?>

            <?php echo e(auth()->user()->role); ?>

        <?php endif; ?>
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="/manager/dist/css/tabler.min.css?1666304673" rel="stylesheet"/>
    <link href="/manager/dist/css/tabler-flags.min.css?1666304673" rel="stylesheet"/>
    <link href="/manager/dist/css/tabler-payments.min.css?1666304673" rel="stylesheet"/>
    <link href="/manager/dist/css/tabler-vendors.min.css?1666304673" rel="stylesheet"/>
    <link href="/manager/dist/css/demo.min.css?1666304673" rel="stylesheet"/>
    <link href="/css/select2.min.css" rel="stylesheet"/>



    <script type="text/javascript" src="/home/js/jquery-2.2.0.min.js"></script>

</head>
<body class="antialiased ">
<div class="page">

    <?php echo $__env->make('admin.section.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="page-wrapper">
        <?php echo $__env->make('admin.section.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="page-body">
            <div class="container-xl">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        <?php echo $__env->make('admin.section.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>
</div>
<script src="/manager/dist/libs/apexcharts/dist/apexcharts.min.js"></script>
<script src="/manager/dist/js/tabler.min.js"></script>
<script src="/home/js/fun.js"></script>
<script type="text/javascript" src="/home/js/iziModal.min.js"></script>
<script type="text/javascript" src="/home/js/lightbox.min.js"></script>
<script type="text/javascript" src="/home/js/persian-date.min.js"></script>
<script type="text/javascript" src="/home/js/persian-datepicker.min.js"></script>
<script type="text/javascript" src="/home/js/plyr.js"></script>
<script type="text/javascript" src="/home/js/tinymce/tinymce.min.js"></script>
<script type="text/javascript" src="/home/js/fun.js"></script>


<script type="text/javascript" src="/home/js/home1.js"></script>
<script src="/manager/dist/js/admin.js"></script>

<script src="/js/select2.full.min.js"></script>

<script src="<?php echo e(asset('/js/js.js')); ?>"></script>
<script src="<?php echo e(asset('/js/app.js')); ?>"></script>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH G:\laravelProject\iman\resources\views/main/manager.blade.php ENDPATH**/ ?>