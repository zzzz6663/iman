

window.onload = function() {
    if (window.jQuery) {
        $(".select2").select2({
        });
    }
}
